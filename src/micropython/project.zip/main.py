"""
Sistema monolitico para o controle do planador ESP32.

Este modulo integra todas as funcionalidades (hardware, sensores, PID, liberacao)
em uma unica classe para operacao simplificada.
"""

import time
import math
import struct
from machine import Pin, PWM, I2C
import gc
import custom_logging as logging

logger = logging.getLogger(__name__)

# Importar configuracoes do arquivo config.py
from config import (
    PLANADOR_SERVOS, RELEASE_SERVO_PIN, LED_SYSTEM_ACTIVE, LED_MODE, LED_ALERT,
    LED_RELEASE, BUTTON_MODE_PIN, BUTTON_POWER_PIN, RC_RELEASE_PIN, I2C_SDA,
    I2C_SCL, MPU6050_ADDR, FLIGHT_MODES, RELEASE_CONFIG, SAFETY_LIMITS
)


class PlanadorESP32:
    """Classe principal que encapsula toda a logica do planador."""

    def __init__(self):
        """Inicializa o sistema do planador, incluindo hardware e estados."""
        logger.info("Iniciando o sistema compacto do planador ESP32.")

        self.flight_mode = 0
        self.system_active = False
        self.loop_count = 0
        self.last_telemetry_time = 0

        self.mode_button_last = False
        self.power_button_last = False
        self.last_button_time = 0

        self.pid_integral = [0, 0, 0]
        self.pid_prev_error = [0, 0, 0]

        self.servos = {}
        self.sensors_available = False
        
        self.release_servo = None
        self.release_state = 'LOCKED'
        self.release_armed_time = 0
        self.release_time = 0
        self.rc_signal_pin = None
        self.last_rc_read = 0

        gc.collect()
        self.run_tests()

    def run_tests(self):
        """Executa testes iniciais simplificados para verificar o hardware."""
        logger.info("Verificando o sistema...")
        tests_ok = 0
        
        if self.init_hardware():
            logger.info("Hardware OK.")
            tests_ok += 1
        else:
            logger.warning("Hardware com problemas.")
            
        if self.init_release_system():
            logger.info("Sistema de liberacao OK.")
            tests_ok += 1
        else:
            logger.warning("Sistema de liberacao com problemas.")
            
        if self.init_sensors():
            logger.info("Sensores OK.")
            tests_ok += 1
        else:
            logger.warning("Modo simulacao ativado para sensores.")
            
        if self.init_servos():
            logger.info("Servos OK.")
            tests_ok += 1
        else:
            logger.warning("Servos com problemas.")
            
        logger.info(f"{tests_ok}/4 sistemas funcionando.")
        gc.collect()

    def init_hardware(self):
        """Inicializa os pinos de hardware basicos como LEDs e botoes."""
        try:
            self.led_system_active = Pin(LED_SYSTEM_ACTIVE, Pin.OUT)
            self.led_mode = Pin(LED_MODE, Pin.OUT)
            self.led_alert = Pin(LED_ALERT, Pin.OUT)
            self.led_release = Pin(LED_RELEASE, Pin.OUT)
            
            for led in [self.led_system_active, self.led_mode, self.led_alert, self.led_release]:
                led.value(1)
                time.sleep_ms(50)
                led.value(0)
                
            self.mode_button = Pin(BUTTON_MODE_PIN, Pin.IN, Pin.PULL_UP)
            try:
                self.power_button = Pin(BUTTON_POWER_PIN, Pin.IN, Pin.PULL_UP)
            except:
                self.power_button = None
                
            return True
        except Exception as e:
            logger.error(f"Erro ao inicializar hardware: {e}")
            return False
            
    def init_release_system(self):
        """Inicializa o servo de liberacao e o pino de sinal RC."""
        try:
            self.release_servo = PWM(Pin(RELEASE_SERVO_PIN), freq=50)
            self.release_servo.duty(self.angle_to_duty(RELEASE_CONFIG['locked_position']))
            self.release_state = 'LOCKED'
            
            self.rc_signal_pin = Pin(RC_RELEASE_PIN, Pin.IN)
            
            self.led_release.value(1)
            
            logger.info(f"Sistema de liberacao TRAVADO (servo em {RELEASE_CONFIG['locked_position']} graus).")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar sistema de liberacao: {e}")
            return False

    def init_sensors(self):
        """Inicializa a comunicacao I2C e tenta configurar o MPU6050."""
        try:
            self.i2c = I2C(0, sda=Pin(I2C_SDA), scl=Pin(I2C_SCL), freq=100000)
            
            try:
                self.i2c.writeto_mem(MPU6050_ADDR, 0x6B, b'\x00')
                time.sleep_ms(50)
                who_am_i = self.i2c.readfrom_mem(MPU6050_ADDR, 0x75, 1)[0]
                if who_am_i == 0x68:
                    self.sensors_available = True
                    return True
            except:
                pass
                
            self.sensors_available = False
            return False
        except Exception as e:
            logger.error(f"Erro ao inicializar sensores: {e}")
            self.i2c = None
            self.sensors_available = False
            return False

    def init_servos(self):
        """Inicializa os servos do planador e os coloca em posicao neutra."""
        self.servos = {}
        servos_ok = 0
        
        for name, pin in PLANADOR_SERVOS.items():
            try:
                servo = PWM(Pin(pin), freq=50)
                servo.duty(self.angle_to_duty(90))
                self.servos[name] = servo
                servos_ok += 1
            except Exception as e:
                logger.error(f"Erro ao inicializar servo {name}: {e}")
                
        return servos_ok == len(PLANADOR_SERVOS)

    @micropython.native
    def angle_to_duty(self, angle):
        """Converte um angulo (0-180) para um valor de duty cycle PWM."""
        return int(40 + (angle * 75) // 180)


    @micropython.native
    def read_sensors(self):
        """Le os dados do MPU6050 ou simula se nao disponivel."""
        if not self.sensors_available:
            t = time.ticks_ms() / 5000.0
            return (math.sin(t) * 5, math.cos(t) * 3, math.sin(t * 0.5) * 2, False)
            
        try:
            data = self.i2c.readfrom_mem(MPU6050_ADDR, 0x3B, 14)
            
            ax = struct.unpack('>h', data[0:2])[0] / 16384.0
            ay = struct.unpack('>h', data[2:4])[0] / 16384.0
            az = struct.unpack('>h', data[4:6])[0] / 16384.0
            gz = struct.unpack('>h', data[12:14])[0] / 131.0
            
            roll = math.atan2(ay, az) * 57.2958
            pitch = math.atan2(-ax, math.sqrt(ay*ay + az*az)) * 57.2958
            
            return (roll, pitch, gz, True)
        except Exception as e:
            logger.error(f"Erro na leitura do MPU6050: {e}")
            t = time.ticks_ms() / 5000.0
            return (math.sin(t) * 5, math.cos(t) * 3, math.sin(t * 0.5) * 2, False)

    @micropython.native  
    def read_rc_signal(self):
        """Le o sinal PWM do receptor RC."""
        current_time = time.ticks_ms()
        
        if time.ticks_diff(current_time, self.last_rc_read) < 50:
            return 1500
            
        self.last_rc_read = current_time
        
        try:
            if not self.rc_signal_pin:
                return 1500
                
            timeout = 0
            while self.rc_signal_pin.value() == 0:
                timeout += 1
                if timeout > 10000:
                    return 1500
                time.sleep_us(1)
            
            start_time = time.ticks_us()
            timeout = 0
            while self.rc_signal_pin.value() == 1:
                timeout += 1
                if timeout > 3000:
                    break
                time.sleep_us(1)
                
            pulse_width = time.ticks_diff(time.ticks_us(), start_time)
            
            if 800 <= pulse_width <= 2200:
                return pulse_width
            else:
                return 1500
                
        except Exception as e:
            logger.error(f"Erro na leitura do sinal RC: {e}")
            return 1500

    @micropython.native
    def calculate_pid(self, roll, pitch, yaw_rate):
        """Calcula as saidas do PID para estabilizacao."""
        mode = FLIGHT_MODES[self.flight_mode]
        gains = mode['gains']
        limits = mode['limits']
        target = mode['target']
        
        roll_error = target[0] - roll
        pitch_error = target[1] - pitch
        yaw_error = -yaw_rate
        
        self.pid_integral[0] += roll_error * 0.1
        self.pid_integral[1] += pitch_error * 0.1  
        self.pid_integral[2] += yaw_error * 0.1
        
        for i in range(3):
            if self.pid_integral[i] > 10:
                self.pid_integral[i] = 10
            elif self.pid_integral[i] < -10:
                self.pid_integral[i] = -10
        
        roll_out = gains[0] * roll_error + gains[1] * self.pid_integral[0]
        pitch_out = gains[3] * pitch_error + gains[4] * self.pid_integral[1]
        yaw_out = gains[6] * yaw_error + gains[7] * self.pid_integral[2]
        
        if roll_out > limits[0]: roll_out = limits[0]
        elif roll_out < -limits[0]: roll_out = -limits[0]
        
        if pitch_out > limits[1]: pitch_out = limits[1]
        elif pitch_out < -limits[1]: pitch_out = -limits[1]
        
        if yaw_out > limits[2]: yaw_out = limits[2]
        elif yaw_out < -limits[2]: yaw_out = -limits[2]
        
        return (roll_out, pitch_out, yaw_out)

    @micropython.native
    def calculate_commands(self, roll, pitch, yaw_rate):
        """Calcula os comandos finais para os servos com base nas saidas do PID."""
        pid_out = self.calculate_pid(roll, pitch, yaw_rate)
        flaps_base = FLIGHT_MODES[self.flight_mode]['flaps']
        
        flaps_left = 90 + flaps_base - pid_out[0]
        flaps_right = 90 + flaps_base + pid_out[0]
        elevator = 90 - pid_out[1]
        rudder = 90 + pid_out[2]
        
        commands = []
        for cmd in [flaps_left, flaps_right, elevator, rudder]:
            if cmd > 150: cmd = 150
            elif cmd < 30: cmd = 30
            commands.append(int(cmd))
            
        return commands

    def update_release_system(self):
        """Atualiza o estado do sistema de liberacao."""
        if not self.release_servo:
            return
            
        current_time = time.ticks_ms()
        rc_signal = self.read_rc_signal()
        
        if self.release_state == 'LOCKED':
            self.led_release.value(1)
            if rc_signal > RELEASE_CONFIG['rc_threshold']:
                self.release_state = 'ARMED'
                self.release_armed_time = current_time
                logger.info("Sistema de liberacao ARMADO.")
                
        elif self.release_state == 'ARMED':
            self.led_release.value((current_time // 200) % 2)
            if rc_signal < RELEASE_CONFIG['rc_threshold']:
                self.release_state = 'LOCKED'
                logger.info("Sistema de liberacao DESARMADO.")
                return
                
            if time.ticks_diff(current_time, self.release_armed_time) >= RELEASE_CONFIG['safety_delay']:
                if rc_signal > RELEASE_CONFIG['rc_threshold']:
                    self.release_state = 'RELEASING'
                    self.release_time = current_time
                    logger.info("Liberando planador!")
                    
        elif self.release_state == 'RELEASING':
            self.led_release.value(0)
            self.release_servo.duty(self.angle_to_duty(RELEASE_CONFIG['release_position']))
            if time.ticks_diff(current_time, self.release_time) >= 500:
                self.release_state = 'RELEASED'
                logger.info("Planador LIBERADO!")
                
        elif self.release_state == 'RELEASED':
            self.led_release.value((current_time // 1000) % 2)
            if time.ticks_diff(current_time, self.release_time) >= RELEASE_CONFIG['auto_lock_time']:
                self.lock_release_system()
                
    def lock_release_system(self):
        """Trava o sistema de liberacao."""
        if self.release_servo:
            self.release_servo.duty(self.angle_to_duty(RELEASE_CONFIG['locked_position']))
            self.release_state = 'LOCKED'
            self.led_release.value(1)
            logger.info("Sistema de liberacao TRAVADO.")
            
    def emergency_release(self):
        """Ativa a liberacao de emergencia via botao."""
        if RELEASE_CONFIG['emergency_override'] and self.release_servo:
            logger.warning("Liberacao de emergencia ativada!")
            self.release_servo.duty(self.angle_to_duty(RELEASE_CONFIG['release_position']))
            self.release_state = 'RELEASED'
            self.release_time = time.ticks_ms()
            
            for _ in range(5):
                self.led_alert.value(1)
                time.sleep_ms(100)
                self.led_alert.value(0)
                time.sleep_ms(100)

    def handle_controls(self):
        """Processa a entrada dos botoes para controlar o sistema."""
        current_time = time.ticks_ms()
        if time.ticks_diff(current_time, self.last_button_time) < 300:
            return
            
        mode_pressed = not self.mode_button.value()
        if mode_pressed and not self.mode_button_last:
            if not self.system_active:
                self.system_active = True
                logger.info(f"Sistema ATIVO - Modo: {FLIGHT_MODES[self.flight_mode]['name']}")
                self.led_system_active.value(1)
            else:
                self.flight_mode = (self.flight_mode + 1) % len(FLIGHT_MODES)
                logger.info(f"Modo alterado para: {FLIGHT_MODES[self.flight_mode]['name']}")
                self.pid_integral = [0, 0, 0]
            self.last_button_time = current_time
        self.mode_button_last = mode_pressed
        
        if self.power_button:
            power_pressed = not self.power_button.value()
            if power_pressed and not self.power_button_last:
                if self.system_active:
                    self.system_active = False
                    logger.info("Sistema DESATIVADO.")
                    self.set_neutral()
                    self.led_system_active.value(0)
                else:
                    self.emergency_release()
                self.last_button_time = current_time
            self.power_button_last = power_pressed

    def set_neutral(self):
        """Coloca todos os servos em posicao neutra."""
        neutral = self.angle_to_duty(90)
        for servo in self.servos.values():
            servo.duty(neutral)

    @micropython.native
    def apply_commands(self, commands):
        """Aplica os comandos calculados aos servos."""
        servo_names = ['flaps_left', 'flaps_right', 'elevator', 'rudder']
        for i, name in enumerate(servo_names):
            if name in self.servos:
                self.servos[name].duty(self.angle_to_duty(commands[i]))

    def update_leds(self):
        """Atualiza o estado dos LEDs de acordo com o sistema."""
        if hasattr(self, 'led_system_active'):
            self.led_system_active.value(1 if self.system_active else 0)
            
            if self.system_active:
                blinks = self.flight_mode + 1
                cycle = (time.ticks_ms() // 400) % (blinks + 2)
                self.led_mode.value(1 if cycle < blinks else 0)
            else:
                self.led_mode.value(0)

    def log_status(self, roll, pitch, yaw_rate, sensors_valid):
        """Registra o status atual do sistema para telemetria."""
        current_time = time.ticks_ms()
        if time.ticks_diff(current_time, self.last_telemetry_time) >= 3000:
            self.last_telemetry_time = current_time
            mode_name = FLIGHT_MODES[self.flight_mode]['name']
            sensor_text = "REAL" if sensors_valid else "SIMULADO"
            status_text = "ATIVO" if self.system_active else "INATIVO"
            release_text = self.release_state
            rc_signal = self.read_rc_signal()
            logger.info(f"Modo: {mode_name} | R:{roll:.1f} P:{pitch:.1f} Y:{yaw_rate:.1f} | Status:{status_text} | Sensor:{sensor_text} | Liberacao:{release_text} RC:{rc_signal}")
            gc.collect()

    def main_loop(self):
        """Executa um ciclo completo de operacao do planador."""
        self.loop_count += 1
        try:
            roll, pitch, yaw_rate, sensors_valid = self.read_sensors()
            self.handle_controls()
            if self.system_active:
                commands = self.calculate_commands(roll, pitch, yaw_rate)
                self.apply_commands(commands)
            else:
                self.set_neutral()
            self.update_release_system()
            self.update_leds()
            if self.loop_count % 30 == 0:
                self.log_status(roll, pitch, yaw_rate, sensors_valid)
        except Exception as e:
            logger.error(f"Erro no loop principal: {e}")
            self.set_neutral()

    def run(self):
        """Inicia o loop de execucao principal do planador."""
        logger.info("Sistema Planador ESP32 - Iniciado")
        logger.info("Controles: Botao AZUL: Ativar/Trocar Modo")
        if self.power_button:
            logger.info("Botao VERMELHO: Desativar")
        logger.info("LED VERDE: Sistema Ativo")
        logger.info("LED AMARELO: Modo (Pisca)")
        
        try:
            while True:
                self.main_loop()
                time.sleep_ms(100)
        except KeyboardInterrupt:
            logger.info("Parando o sistema...")
        finally:
            self.cleanup()

    def cleanup(self):
        """Realiza a limpeza final dos componentes de hardware."""
        logger.info("Finalizando o sistema...")
        self.set_neutral()
        
        if self.release_servo:
            try:
                self.release_servo.duty(self.angle_to_duty(RELEASE_CONFIG['locked_position']))
                logger.info("Sistema de liberacao travado por seguranca.")
            except:
                pass
        
        if hasattr(self, 'led_system_active'):
            try:
                self.led_system_active.value(0)
                self.led_mode.value(0)
                self.led_alert.value(0)
                self.led_release.value(0)
            except:
                pass
        
        for servo in self.servos.values():
            try:
                servo.deinit()
            except:
                pass
                
        if self.release_servo:
            try:
                self.release_servo.deinit()
            except:
                pass
                
        logger.info("Sistema finalizado.")

def main():
    """Ponto de entrada para iniciar o sistema do planador."""
    logger.info("Iniciando o sistema do planador...")
    try:
        planador = PlanadorESP32()
        planador.run()
    except Exception as e:
        logger.error(f"Erro critico: {e}")
        import sys
        sys.print_exception(e)

if __name__ == "__main__":
    main()
